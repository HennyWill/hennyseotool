'''

VERSION 1.02
- added text auto-save to excel after getting responses with all subheadings

'''

import os
import time

import openai
from openpyxl import load_workbook
from openpyxl import Workbook
from datetime import datetime

start_time = time.time()
openai.api_key = "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"

def get_response(prompt_text):
    while True:
        try:
            response = openai.Completion.create(
                engine="text-davinci-003",
                prompt=prompt_text,
                temperature=0.9,
                max_tokens=3800,
                top_p=1,
                frequency_penalty=0,
                presence_penalty=0)
        except Exception as e:  # exception handling and retrying to send request (maybe TimeoutError or RateLimitError)
            print('Failed due to exception ' + str(e) + ". Retrying to send a new request...")
            time.sleep(2)
            continue
        else:
            return response


data_file = 'oaidata.xlsx'  # path to excel file
wb = load_workbook(data_file)  # Load the entire workbook (excel file with the drug names)

sheetOne = wb['Sheet1']  # Load the worksheet with drug names
keyword_list = [row.value for row in sheetOne['A'] if row.value is not None]  # stores drug names

sheetTwo = wb['Sheet2']  # Load the worksheet with subheadings
subheadings_list = [row.value for row in sheetTwo['A'] if row.value is not None]  # stores subheadings

# write results to a new workbook (new excel file)
workbook = Workbook()
sheet = workbook.active
random_output_file_name = keyword_list[0] + '-' + keyword_list[len(keyword_list) - 1] + '.xlsx'

result_dict = dict()#dict.fromkeys(keyword_list, 0)  # stores drug name and full text for it
try:
    for i in range(0, len(keyword_list)):
        topic = keyword_list[i] #name of the drug
        text = "" # variable for text addition. when the text if full - write it's data to result_dict
        for j in range(3, len(subheadings_list), 4):
            prompt_text = f"Write a detailed text on the topic \"{topic}\" in Czech. Use html markup. Use the following subheadings." \
                      f"\n {topic} {subheadings_list[j - 3]}" \
                      f"\n {topic} {subheadings_list[j - 2]}" \
                      f"\n {topic} {subheadings_list[j - 1]}" \
                      f"\n {topic} {subheadings_list[j]}"
            print(prompt_text)
            response = get_response(prompt_text)
            text = text + response.choices[0].text
        str_to_replace = f"<h1>{topic}</h1>"
        if str_to_replace in text:
            text = text.replace(str_to_replace, "")
        result_dict[keyword_list[i]] = text.replace("h1", "h2") #write full text to result dictionary
        for row, (keyword, texts) in enumerate(result_dict.items(), start=1):  # row - counter for number of the cell initial value: (start=1); (keyword, count) - iterate through the dictionary key and value
            sheet[f"A{row}"] = keyword
            sheet[f"B{row}"] = texts
        workbook.save(random_output_file_name)

finally:
    print("--- %s seconds ---" % (time.time() - start_time))
    print('Result saved to '+ random_output_file_name)
